//
//  TimeBarViewController.swift
//  TriviaSwag
//
//  Created by 谢乾坤 on 4/8/16.
//  Copyright © 2016 QiankunXie. All rights reserved.
//

import UIKit

class TimeBarViewController: UIViewController {

    var firstTimeBar: UIImageView?
    var secondTimeBar: UIImageView?

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // use when start to display answers
    func initTimeBar() {
        
        if firstTimeBar != nil {
            firstTimeBar?.removeFromSuperview()
        }
        if secondTimeBar != nil {
            secondTimeBar?.removeFromSuperview()
        }
        
        self.firstTimeBar = self.addTimeBarBackground("TimePlayer1")
        self.secondTimeBar = self.addTimeBarBackground("TimePlayer2")
        
        setupAnimation(firstTimeBar!)
        setupAnimation(secondTimeBar!)
    }
    
    func addTimeBarBackground(figureName: String) -> UIImageView{
        
        let width = view.bounds.size.width
        let height = view.bounds.size.height
        
        let imageViewBackground = UIImageView(frame: CGRectMake(0, 0, width, height))
        imageViewBackground.image = UIImage(named: figureName)
        
        imageViewBackground.contentMode = UIViewContentMode.ScaleToFill
        view.backgroundColor = UIColor.clearColor()
        view.addSubview(imageViewBackground)
        view.sendSubviewToBack(imageViewBackground)
        
        return imageViewBackground
    }

    
    func setupAnimation(backgroundView: UIImageView){
        
        let tempBounds = backgroundView.bounds
        backgroundView.bounds = CGRectMake(0, 0, 0, tempBounds.height)
        backgroundView.alpha = 0;
        
        UIView.animateWithDuration(0.5, delay: 0, options: [], animations: {
            
            backgroundView.bounds = tempBounds
            backgroundView.alpha = 1
            
            }, completion: nil)
    }
    
    // clear the time bar
    
    func clearTimebars() {
        
        if self.firstTimeBar != nil && self.secondTimeBar != nil {
            
            self.clearAnimation(self.firstTimeBar!)
            self.clearAnimation(self.secondTimeBar!)
        } else {
            print("Should add timebar background first")
        }

        
    }
    
    func clearAnimation(backgroundView: UIImageView){
        let tempBounds = backgroundView.bounds
        
        UIView.animateWithDuration(0.5, delay: 0, options: [], animations: {
            
            backgroundView.bounds = CGRectMake(0, 0, 0, tempBounds.height)
            backgroundView.alpha = 0
            
            }, completion: nil)

    }
    
    
    

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
