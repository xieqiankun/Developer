//
//  AnswersDisplayViewController.swift
//  TriviaSwag
//
//  Created by 谢乾坤 on 4/8/16.
//  Copyright © 2016 QiankunXie. All rights reserved.
//

import UIKit

class AnswersDisplayViewController: UIViewController {

    
    @IBOutlet var answerViews: [UIView]!
    
    @IBOutlet var answerButtons: [UIButton]!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupAnswersButtons()
        self.hideAnswerViews()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupAnswersButtons(){
        
        for view in self.answerViews {
            
            let width = view.bounds.size.width
            let height = view.bounds.size.height
            
            let imageViewBackground = UIImageView(frame: CGRectMake(0, 0, width, height))
            imageViewBackground.image = UIImage(named: "AnswerUntouched")
            
            imageViewBackground.contentMode = UIViewContentMode.ScaleToFill
            view.backgroundColor = UIColor.clearColor()
            view.addSubview(imageViewBackground)
            view.sendSubviewToBack(imageViewBackground)

        }

    }
    
    func hideAnswerViews() {
        
        for view in self.answerViews {
            view.hidden = true
        }
        
    }
    
    func displayAnswerViews() {
        
        for view in self.answerViews {
            view.hidden = false
        }
        
    }
    
    // For display the answers when it is ready
    func readyForDisplayAnswerViews(answers: [String]) {
        
        self.displayAnswerViews()
        
        for i in 0 ..< 4 {
            let btn = self.answerButtons[i]
            btn.setTitle(answers[i], forState: .Normal)
        }
        
        self.displayAnimationForButtons()
    }
    
    func displayAnimationForButtons(){
        
        for i in 0 ..< 4 {
            let imageView = self.answerViews[i].subviews[0]
            let temp = imageView.bounds
            imageView.bounds = CGRectMake(0, 0, 0, 0)
            imageView.alpha = 0
            
            
            let label = self.answerButtons[i].titleLabel
            label?.transform = CGAffineTransformScale((label?.transform)!, 0.1, 0.1)
            label?.alpha = 0
            
            UIView.animateWithDuration(0.5, delay:Double(i)/8 , usingSpringWithDamping: 0.7, initialSpringVelocity: 0.2, options: .CurveEaseInOut, animations: {
                
                label?.transform = CGAffineTransformScale((label?.transform)!, 10, 10)
                imageView.bounds = temp
                imageView.alpha = 1
                label?.alpha = 1
                }, completion: nil)
            
        }
    }
    
    // buttons disappear
    func answerButtonsFadeOut(){
        
        for i in 0 ... 3 {
            
            let imageView = self.answerViews[i].subviews[0]
            let label = self.answerButtons[i].titleLabel

            UIView.animateWithDuration(0.5, delay: Double(i)/8, options: [], animations: { 
                
                label?.alpha = 0
                imageView.alpha = 0
                
                }, completion: nil)
            
        }
        
        
        
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
     //
    }
    */

}
